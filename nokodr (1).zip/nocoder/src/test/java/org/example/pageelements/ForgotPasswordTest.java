package org.example.pageelements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class ForgotPasswordTest {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();
        wait = new WebDriverWait(driver,Duration.ofSeconds(20));

        // Visit the forgot password page
        driver.get("https://app-staging.nokodr.com/");
        driver.findElement(By.xpath("/html/body/app-root/login/abx-auth-container/div/div[2]/div/abx-login/div/a")).click();
    }

//    @Test
    public void validateEmailField() {
        WebElement emailField = wait.until(
                ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/abx-modal/section/div/div/abx-forgot-password/div/div/div/abx-tabs/div/div/abx-tab[1]/div/div/abx-form/div/div/abx-container/div/div/div/span/abx-layout-item/div/abx-field/div/div/div/div[1]/abx-email/input"))
        );

        WebElement proceedButton = driver.findElement(By.xpath("//div[@title=\"Proceed\"]"));

        // Check that email field is mandatory
        Assert.assertTrue(emailField.isDisplayed(), "Email field is visible");

        // Check if submit button is disabled when email is blank
        Assert.assertTrue(proceedButton.isDisplayed(), "Submit button should be disabled when email is blank");
    }

//    @Test
    public void validateEmailFormat() {
        WebElement emailField = wait.until(
                ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/abx-modal/section/div/div/abx-forgot-password/div/div/div/abx-tabs/div/div/abx-tab[1]/div/div/abx-form/div/div/abx-container/div/div/div/span/abx-layout-item/div/abx-field/div/div/div/div[1]/abx-email/input"))
        );

        WebElement proceedButton = driver.findElement(By.xpath("//div[@title=\"Proceed\"]"));

        // Test invalid email format
        emailField.sendKeys("kkkkkut7877785@gmail.com");
        proceedButton.click();

        // Wait for the error message to appear (using WebDriverWait)
        WebElement errorMessageElement = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.slds-notify__content h2"))
        );
        // Assert the error message for invalid email format
        Assert.assertTrue(errorMessageElement.getText().contains("User does not exists"), "Error message should be shown for invalid email format");

        // Clear the email field
        emailField.clear();
    }

    @Test
    public void testValidEmail() {
        WebElement emailField = wait.until(
                ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/abx-modal/section/div/div/abx-forgot-password/div/div/div/abx-tabs/div/div/abx-tab[1]/div/div/abx-form/div/div/abx-container/div/div/div/span/abx-layout-item/div/abx-field/div/div/div/div[1]/abx-email/input"))
        );

        WebElement proceedButton = driver.findElement(By.xpath("//div[@title=\"Proceed\"]"));


        // Test valid registered email
        emailField.sendKeys("pramodkoli2333@gmail.com");
        proceedButton.click();

        // Wait for the success message (or redirection to success page)
        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.slds-notify__content h2")));

        WebElement verifyCodeElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"modal-content-id-1\"]/verification-code/div/div[2]/div/abx-button/button")));
        // Assert that the success message is correct
        Assert.assertFalse(verifyCodeElement.isEnabled());

        
        Assert.assertTrue(successMessage.getText().contains("Verification code sent successfully"), "Success message should appear for valid email");
    }

//    @Test
    public void testNonRegisteredEmail() {
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement submitButton = driver.findElement(By.id("submitButton"));

        // Test non-registered email
        emailField.sendKeys("nonregistered@domain.com");
        submitButton.click();

        // Wait for the error message to appear
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("error_message")));

        // Assert that the error message for non-registered email is shown
        Assert.assertTrue(errorMessage.getText().contains("Email not found"), "Error message should appear for non-registered email");
    }

//    @Test
    public void testBlankEmailField() {
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement submitButton = driver.findElement(By.id("submitButton"));

        // Test blank email field
        emailField.clear();
        submitButton.click();

        // Wait for the error message to appear
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("error_message")));

        // Assert that the error message for blank email field is shown
        Assert.assertTrue(errorMessage.getText().contains("Email is required"), "Error message should appear for blank email field");
    }

//    @AfterMethod
    public void tearDown() {
        // Close the browser after each test
        driver.quit();
    }
}

